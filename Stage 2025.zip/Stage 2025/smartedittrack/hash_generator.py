# hash_generator.py
import openpyxl
import hashlib
import os
import csv
from openpyxl.styles import Protection

def generate_student_files_csv(input_csv="liste_etudiants.csv",
                                template_path="Fichier_Excel_Professeur_Template.xlsx",
                                output_folder="copies_generees",
                                log_file="hash_records.csv"):

    os.makedirs(output_folder, exist_ok=True)

    etudiants = []
    with open(input_csv, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            etudiants.append({
                "id": row["id"].strip(),
                "nom": row["nom"].strip(),
                "prenom": row["prenom"].strip()
            })

    with open(log_file, "w", newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["id_etudiant", "nom", "prenom", "hash", "nom_fichier"])

        for etudiant in etudiants:
            id_etudiant = etudiant["id"]
            nom = etudiant["nom"]
            prenom = etudiant["prenom"]

            wb = openpyxl.load_workbook(template_path)
            ws = wb.active

            ws["Z1"] = id_etudiant
            contenu_concatene = id_etudiant.encode()

            for row in ws.iter_rows(values_only=True):
                for cell in row:
                    if cell:
                        contenu_concatene += str(cell).encode()

            hash_etudiant = hashlib.sha256(contenu_concatene).hexdigest()
            ws["Z2"] = hash_etudiant
            ws.column_dimensions['Z'].hidden = True

            for row_cells in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=3, max_col=25):
                for cell in row_cells:
                    cell.protection = Protection(locked=False)

            ws.protection.sheet = True
            ws.protection.enable()

            nom_fichier = f"{id_etudiant}_{nom}_{prenom}.xlsx"
            chemin_sortie = os.path.join(output_folder, nom_fichier)
            wb.save(chemin_sortie)

            writer.writerow([id_etudiant, nom, prenom, hash_etudiant, nom_fichier])

    return output_folder
