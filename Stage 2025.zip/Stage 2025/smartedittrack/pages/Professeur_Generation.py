import streamlit as st
import zipfile
import os
from hash_generator import generate_student_files_csv

def app():
    st.header("👨‍🏫 Génération des copies Excel des étudiants")

    if st.button("📥 Générer les copies à partir de liste_etudiants.csv"):
        dossier_copies = generate_student_files_csv()

        zip_path = "copies_zip/copies_etudiants.zip"
        os.makedirs("copies_zip", exist_ok=True)
        with zipfile.ZipFile(zip_path, 'w') as zipf:
            for file in os.listdir(dossier_copies):
                file_path = os.path.join(dossier_copies, file)
                zipf.write(file_path, arcname=file)

        st.success("✅ Copies générées avec succès !")
        with open(zip_path, "rb") as f:
            st.download_button(
                label="📦 Télécharger les copies ZIP",
                data=f,
                file_name="copies_etudiants.zip",
                mime="application/zip"
            )
