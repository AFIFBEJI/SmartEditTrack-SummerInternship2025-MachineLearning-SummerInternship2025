import streamlit as st
import os
import json
from compare_excels import comparer_etudiant

copies_folder = "copies_etudiants"
rapport_folder = "rapports_etudiants"
notif_file = "notif_depot.json"

os.makedirs(rapport_folder, exist_ok=True)

def charger_notifications():
    if os.path.exists(notif_file):
        with open(notif_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def sauvegarder_notifications(liste):
    with open(notif_file, "w", encoding="utf-8") as f:
        json.dump(liste, f)

def nettoyer_notifications():
    notifs = charger_notifications()
    fichiers_valides = [f for f in notifs if os.path.exists(os.path.join(copies_folder, f))]
    if len(fichiers_valides) != len(notifs):
        sauvegarder_notifications(fichiers_valides)
    return fichiers_valides

def app():
    st.header("👨‍🏫 Analyse et gestion des copies des étudiants")

    fichiers_deposes = nettoyer_notifications()

    st.write(f"🔔 {len(fichiers_deposes)} dépôt(s) reçu(s).")

    if fichiers_deposes:
        st.subheader("📋 Fichiers déposés par les étudiants :")
        for f in fichiers_deposes:
            st.write(f"- {f}")

        if st.button("🔍 Lancer l'analyse des dépôts"):
            with st.spinner("Analyse en cours..."):
                rapports = []
                for fichier in fichiers_deposes:
                    chemin_fichier = os.path.join(copies_folder, fichier)
                    if os.path.exists(chemin_fichier):
                        rapport = comparer_etudiant(chemin_fichier)
                        rapports.append(rapport)
                    else:
                        rapports.append(f"⚠️ Fichier manquant : {fichier}")
                st.success("✅ Analyse terminée !")
                for r in rapports:
                    st.text(r)

        if st.button("📭 Réinitialiser la liste des notifications"):
            sauvegarder_notifications([])
            st.experimental_rerun()
    else:
        st.info("Aucun dépôt détecté.")

    st.markdown("---")
    st.subheader("📤 Déposer une copie corrigée pour les étudiants")
    fichier_corrige = st.file_uploader("Déposez un fichier Excel corrigé (.xlsx)", type=["xlsx"])

    if fichier_corrige:
        chemin_corrige = os.path.join("copies_corrigees", fichier_corrige.name)
        os.makedirs("copies_corrigees", exist_ok=True)
        with open(chemin_corrige, "wb") as f:
            f.write(fichier_corrige.getbuffer())
        st.success(f"✅ Copie corrigée déposée sous : {fichier_corrige.name}")
