import streamlit as st
import os
from analyzer import comparer_etudiant
import glob

# === CONFIGURATION ===
copies_folder = "copies_etudiants"
rapport_folder = "rapports_etudiants"

st.set_page_config(page_title="SmartEditTrack Professeur", page_icon="🧑‍🏫", layout="wide")
st.title("🧑‍🏫 Interface Professeur - Analyse des devoirs")

# === Liste des fichiers Excel étudiants ===
fichiers = glob.glob(os.path.join(copies_folder, "*.xlsx"))

if not fichiers:
    st.warning("Aucun devoir reçu pour le moment.")
else:
    for fichier in fichiers:
        nom_fichier = os.path.basename(fichier)
        with st.expander(f"📄 {nom_fichier}"):
            if st.button("Analyser ce fichier", key=nom_fichier):
                resultat = comparer_etudiant(fichier)
                st.success(resultat)

            # Vérifier s’il existe un rapport
            nom_txt = os.path.splitext(nom_fichier)[0] + "_rapport.txt"
            chemin_rapport = os.path.join(rapport_folder, nom_txt)

            if os.path.exists(chemin_rapport):
                with open(chemin_rapport, "r", encoding="utf-8") as f:
                    contenu = f.read()
                    st.text_area("📝 Rapport", contenu, height=300)
                    st.download_button("📥 Télécharger le rapport", contenu, file_name=nom_txt)
