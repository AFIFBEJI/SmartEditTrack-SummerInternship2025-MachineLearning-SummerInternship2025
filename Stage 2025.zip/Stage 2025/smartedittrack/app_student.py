import streamlit as st
import openpyxl
import hashlib
import os

# === CONFIG ===
template_hash_folder = "hash_records.csv"
dossier_copies = "copies_etudiants"

os.makedirs(dossier_copies, exist_ok=True)

# === Fonction pour recalculer le hash ===
def recalculer_hash_depuis_contenu(ws, id_etudiant):
    contenu_concatene = id_etudiant.encode()
    for row in ws.iter_rows(values_only=True):
        for cell in row:
            if cell:
                contenu_concatene += str(cell).encode()
    return hashlib.sha256(contenu_concatene).hexdigest()

# === UI Streamlit ===
st.set_page_config(page_title="SmartEditTrack Étudiant", page_icon="📘")
st.title("📘 Dépôt de devoir - Interface Étudiant")
st.write("Merci d'envoyer votre devoir sous format Excel uniquement.")

nom = st.text_input("Nom")
prenom = st.text_input("Prénom")
id_etudiant = st.text_input("ID Étudiant")

fichier = st.file_uploader("Déposez votre fichier Excel ici (.xlsx)", type=["xlsx"])

if st.button("Envoyer") and fichier and nom and prenom and id_etudiant:
    try:
        # Lire le fichier Excel
        wb = openpyxl.load_workbook(fichier)
        ws = wb.active

        id_cell = ws["Z1"].value
        hash_cell = ws["Z2"].value
        hash_calcule = recalculer_hash_depuis_contenu(ws, id_cell)

        if id_cell != id_etudiant:
            st.error("❌ ID dans le fichier ne correspond pas à celui saisi.")
        elif hash_cell != hash_calcule:
            st.warning("⚠️ Fichier modifié ou corrompu (hash ne correspond pas).")
        else:
            nom_fichier = f"{id_etudiant}_{nom}_{prenom}.xlsx"
            chemin_fichier = os.path.join(dossier_copies, nom_fichier)
            wb.save(chemin_fichier)
            st.success("✅ Fichier envoyé avec succès !")
    except Exception as e:
        st.error(f"Erreur : {e}")
