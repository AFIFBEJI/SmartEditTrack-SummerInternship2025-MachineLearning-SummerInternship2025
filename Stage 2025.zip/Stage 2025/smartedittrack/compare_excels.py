import openpyxl
import hashlib
import os
import re
import pandas as pd
import numpy as np
import difflib
from datetime import datetime
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import openpyxl.utils

# === CONFIGURATION ===
template_path = "Fichier_Excel_Professeur_Template.xlsx"
copies_folder = "copies_etudiants"
rapport_folder = "rapports_etudiants"
hash_log_file = "hash_records.csv"
cours_file = "cours_references.txt"
dataset_ia_file = "dataset.csv"

os.makedirs(rapport_folder, exist_ok=True)

# Charger hash log
hash_dict = {}
if os.path.exists(hash_log_file):
    with open(hash_log_file, "r", encoding="utf-8") as f:
        next(f)
        for line in f:
            id_etudiant, nom, prenom, hash_val, nom_fichier = line.strip().split(",")
            hash_dict[nom_fichier] = {
                "id": id_etudiant,
                "nom": nom,
                "prenom": prenom,
                "hash": hash_val
            }

# Charger contenu cours
cours_content = ""
if os.path.exists(cours_file):
    with open(cours_file, "r", encoding="utf-8") as f:
        cours_content = f.read().lower()

# Charger dataset IA
df_ia = None
vectorizer = None
tfidf_matrix = None
if os.path.exists(dataset_ia_file):
    try:
        df_ia = pd.read_csv(dataset_ia_file)
        vectorizer = TfidfVectorizer(stop_words='french')
        tfidf_matrix = vectorizer.fit_transform(df_ia['reponse'])
    except Exception as e:
        print(f"Erreur chargement dataset IA: {e}")

def recalculer_hash_depuis_contenu(ws, id_etudiant):
    contenu_concatene = id_etudiant.encode()
    for row in ws.iter_rows(values_only=True):
        for cell in row:
            if cell:
                contenu_concatene += str(cell).encode()
    return hashlib.sha256(contenu_concatene).hexdigest()

def detecter_triche(reponse, question):
    if not reponse or not isinstance(reponse, str):
        return "Réponse vide ou non textuelle"
    reponse = reponse.strip()
    reponse_lower = reponse.lower()

    if cours_content:
        seq_matcher = difflib.SequenceMatcher(None, reponse_lower, cours_content)
        match = seq_matcher.find_longest_match(0, len(reponse_lower), 0, len(cours_content))
        if match.size > 50:
            ratio = seq_matcher.ratio()
            if ratio > 0.8:
                return f"Copier-coller du cours détecté (similarité : {ratio*100:.1f}%)"

    ia_keywords = [
        "en tant que", "système", "fonctionnalité", "dans le cadre",
        "il est important de noter", "cependant", "par conséquent",
        "d'après la", "selon les", "il convient de", "dans un premier temps"
    ]
    if any(keyword in reponse_lower for keyword in ia_keywords):
        return "Style typique d'une réponse IA détecté"

    if "définir" in question.lower() and len(reponse) < 20:
        return "Réponse trop courte pour une définition"
    if "expliquer" in question.lower() and len(reponse) < 30:
        return "Réponse trop courte pour une explication"

    if re.search(r'[^\w\s.,;:?!\'"()\-]', reponse):
        return "Caractères spéciaux suspects détectés"

    if df_ia is not None and vectorizer is not None:
        try:
            new_vec = vectorizer.transform([reponse])
            similarities = cosine_similarity(new_vec, tfidf_matrix)
            max_sim = np.max(similarities)
            if max_sim > 0.65:
                idx = np.argmax(similarities)
                label = df_ia.iloc[idx]['label']
                return "Réponse probablement générée par IA" if label == 0 else "Réponse humaine probable"
        except Exception:
            pass

    return "Réponse normale"

def comparer_etudiant(fichier_etudiant):
    nom_fichier = os.path.basename(fichier_etudiant)
    data_hash = hash_dict.get(nom_fichier, None)

    try:
        wb_prof = openpyxl.load_workbook(template_path)
        wb_etud = openpyxl.load_workbook(fichier_etudiant)
        ws_prof = wb_prof.active
        ws_etud = wb_etud.active
    except Exception as e:
        return f"❌ Erreur d'ouverture des fichiers : {e}"

    id_cell = ws_etud["Z1"].value
    hash_cell = ws_etud["Z2"].value
    hash_calcule = recalculer_hash_depuis_contenu(ws_etud, id_cell)

    rapport = []
    rapport.append(f"📄 Rapport : {nom_fichier}")
    rapport.append(f"📅 Date : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    rapport.append(f"🧑 ID Étudiant : {id_cell}")
    rapport.append(f"🔐 Hash (Z2) dans le fichier : {hash_cell}")
    rapport.append(f"📁 Hash recalculé à partir du contenu : {hash_calcule}\n")

    if not id_cell or not hash_cell:
        rapport.append("🚨 Problème critique : L'ID étudiant ou le hash (Z2) est manquant dans le fichier.")
    elif data_hash and hash_cell != data_hash["hash"]:
        rapport.append("🚨 Alerte : Le hash Z2 diffère du hash officiel enregistré pour cette copie.")
    elif data_hash and hash_cell == data_hash["hash"]:
        if hash_calcule != hash_cell:
            rapport.append("ℹ️ L'étudiant a utilisé la copie officielle fournie par le professeur (hash Z2 conforme).")
            rapport.append("   Le contenu a été modifié après remplissage du devoir, ce qui est attendu et normal.")
            rapport.append("✅ Le fichier initial est authentique.")
        else:
            rapport.append("✅ Intégrité parfaite : Le fichier est authentique et non modifié depuis sa génération.")
    else:
        if hash_calcule != hash_cell:
            rapport.append("🚨 Alerte : Le contenu du fichier a été modifié (hash recalculé différent du hash Z2),")
            rapport.append("   et le hash Z2 ne correspond pas au hash officiel enregistré.")
        else:
            rapport.append("⚠️ Attention : Hash Z2 absent des enregistrements officiels, mais contenu intact selon hash recalculé.")

    if data_hash and hash_cell == data_hash["hash"]:
        rapport.append("\n📌 REMARQUE IMPORTANTE :")
        rapport.append("L’étudiant a bien utilisé la copie Excel officielle transmise par le professeur.")
        rapport.append("Le hash Z2 correspond exactement à celui de la version originale.")
        rapport.append("Toute modification détectée ensuite correspond au travail effectué par l’élève pour remplir le devoir.")

    rapport.append("\n🔎 Détails des cellules suspectes :")
    total_suspects = 0
    max_row = max(ws_prof.max_row, ws_etud.max_row)
    max_col = max(ws_prof.max_column, ws_etud.max_column)
    for row in range(2, max_row + 1):
        for col in range(1, max_col + 1):
            if col >= 26:  # ignore colonne Z et après
                continue
            val_prof = ws_prof.cell(row=row, column=col).value
            val_etud = ws_etud.cell(row=row, column=col).value
            if val_prof != val_etud:
                question = ws_prof.cell(row=1, column=col).value or "(question inconnue)"
                type_triche = detecter_triche(str(val_etud), str(question))
                if type_triche not in ["Réponse normale", "Réponse humaine probable"]:
                    col_letter = openpyxl.utils.get_column_letter(col)
                    rapport.append(f"\n✏️ Cellule {col_letter}{row} : {type_triche}")
                    rapport.append(f"   • Réponse Étudiant : {val_etud}")
                    total_suspects += 1

    rapport.append(f"\n🧾 Total de cellules suspectes détectées : {total_suspects}")
    if total_suspects == 0:
        rapport.append("✅ Aucun changement suspect détecté.")

    nom_txt = os.path.splitext(nom_fichier)[0] + "_rapport.txt"
    chemin_rapport = os.path.join(rapport_folder, nom_txt)
    with open(chemin_rapport, "w", encoding="utf-8") as f:
        f.write("\n".join(rapport))

    return f"📁 Rapport généré : {chemin_rapport}"

# === Exécution script ===
if __name__ == "__main__":
    print("🔍 Analyse des copies en cours...\n")
    for fichier in os.listdir(copies_folder):
        if fichier.endswith(".xlsx"):
            chemin = os.path.join(copies_folder, fichier)
            print(comparer_etudiant(chemin))
    print("\n✅ Analyse terminée. Rapports disponibles dans :", rapport_folder)
