import streamlit as st
import os
import json
from compare_excels import comparer_etudiant  # ta fonction d’analyse ici

copies_generees_dir = "copies_generees"
copies_etudiants_dir = "copies_etudiants"
rapports_dir = "rapports_etudiants"
notif_file = "notif_depot.json"

os.makedirs(copies_generees_dir, exist_ok=True)
os.makedirs(copies_etudiants_dir, exist_ok=True)
os.makedirs(rapports_dir, exist_ok=True)

st.set_page_config(page_title="SmartEditTrack - Professeur", layout="wide")
st.title("👨‍🏫 Interface Professeur - SmartEditTrack")

def charger_notifications():
    if os.path.exists(notif_file):
        with open(notif_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def sauvegarder_notifications(liste):
    with open(notif_file, "w", encoding="utf-8") as f:
        json.dump(liste, f)

# Nettoyage : ne garder que les fichiers qui existent réellement
def nettoyer_notifications():
    notifs = charger_notifications()
    fichiers_valides = [f for f in notifs if os.path.exists(os.path.join(copies_etudiants_dir, f))]
    if len(fichiers_valides) != len(notifs):
        sauvegarder_notifications(fichiers_valides)
    return fichiers_valides

menu = st.radio("⚙️ Choisissez une action :", [
    "1️⃣ Générer les copies Excel des étudiants",
    "2️⃣ Voir les dépôts des étudiants et rapports",
    "3️⃣ Analyser tous les dépôts reçus"
])

if menu == "1️⃣ Générer les copies Excel des étudiants":
    st.header("📥 Génération des copies Excel pour les étudiants")

    from hash_generator import generate_student_files_csv  # ta fonction déjà dispo

    if st.button("📥 Générer les copies à partir de liste_etudiants.csv"):
        dossier = generate_student_files_csv()
        st.success(f"✅ Copies générées dans le dossier : {dossier}")

        import zipfile
        zip_path = "copies_zip/copies_etudiants.zip"
        os.makedirs("copies_zip", exist_ok=True)
        with zipfile.ZipFile(zip_path, 'w') as zipf:
            for f in os.listdir(dossier):
                zipf.write(os.path.join(dossier, f), arcname=f)
        with open(zip_path, "rb") as fzip:
            st.download_button("📦 Télécharger toutes les copies ZIP", fzip, file_name="copies_etudiants.zip")

elif menu == "2️⃣ Voir les dépôts des étudiants et rapports":
    st.header("📂 Liste des copies déposées par les étudiants")

    fichiers_deposes = nettoyer_notifications()
    nb_depots = len(fichiers_deposes)
    st.write(f"🔔 {nb_depots} dépôt(s) reçu(s)")

    if nb_depots == 0:
        st.info("Aucun dépôt détecté pour l'instant.")
    else:
        fichier_choisi = st.selectbox("📄 Choisissez un dépôt étudiant :", fichiers_deposes)

        if fichier_choisi:
            chemin_depot = os.path.join(copies_etudiants_dir, fichier_choisi)
            if os.path.exists(chemin_depot):
                with open(chemin_depot, "rb") as fdep:
                    st.download_button(f"📥 Télécharger la copie déposée : {fichier_choisi}", fdep,
                                       file_name=fichier_choisi,
                                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            else:
                st.error("❌ Fichier Excel déposé introuvable.")

            nom_rapport = os.path.splitext(fichier_choisi)[0] + "_rapport.txt"
            chemin_rapport = os.path.join(rapports_dir, nom_rapport)
            if os.path.exists(chemin_rapport):
                st.markdown("---")
                st.subheader("📑 Rapport d'analyse")
                with open(chemin_rapport, "r", encoding="utf-8") as frep:
                    rapport_texte = frep.read()
                st.text_area("Contenu du rapport :", value=rapport_texte, height=300)
                with open(chemin_rapport, "rb") as frepbin:
                    st.download_button("📥 Télécharger le rapport", frepbin, file_name=nom_rapport)
            else:
                st.info("⚠️ Aucun rapport généré pour cette copie.")

        if st.button("📭 Réinitialiser la liste des notifications (marquer tous comme lus)"):
            sauvegarder_notifications([])
            st.success("✅ Notifications réinitialisées.")
            st.info("🔄 Merci de recharger la page manuellement pour voir les changements.")

elif menu == "3️⃣ Analyser tous les dépôts reçus":
    st.header("🔍 Analyse automatique des copies déposées")

    fichiers_deposes = nettoyer_notifications()

    if len(fichiers_deposes) == 0:
        st.info("Aucun dépôt détecté à analyser.")
    else:
        if st.button("▶️ Lancer l'analyse de tous les dépôts"):
            with st.spinner("Analyse en cours..."):
                rapports = []
                for fichier in fichiers_deposes:
                    chemin = os.path.join(copies_etudiants_dir, fichier)
                    if os.path.exists(chemin):
                        rapport = comparer_etudiant(chemin)
                        rapports.append(rapport)
                    else:
                        rapports.append(f"⚠️ Fichier manquant : {fichier}")

                st.success("✅ Analyse terminée !")
                for r in rapports:
                    st.text(r)

            st.info("🔄 Merci de recharger la page manuellement pour actualiser la liste.")

