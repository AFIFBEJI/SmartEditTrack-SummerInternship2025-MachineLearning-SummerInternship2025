import streamlit as st
import os
import openpyxl
import hashlib
import json

st.set_page_config(page_title="SmartEditTrack - Étudiant", layout="centered")
st.title("🎓 Interface Étudiant - SmartEditTrack")

# === CONFIGURATION ===
copie_dir = "copies_generees"
depot_dir = "copies_etudiants"
notif_file = "notif_depot.json"
os.makedirs(depot_dir, exist_ok=True)
if not os.path.exists(notif_file):
    with open(notif_file, "w") as f:
        json.dump([], f)

# === IDENTIFIANT ÉTUDIANT ===
id_etudiant = st.text_input("🔑 Entrez votre ID Étudiant")

# === TÉLÉCHARGEMENT DE LA COPIE ===
if id_etudiant:
    fichiers = os.listdir(copie_dir)
    fichiers_id = [f for f in fichiers if f.startswith(id_etudiant)]

    if fichiers_id:
        nom_fichier = fichiers_id[0]
        chemin = os.path.join(copie_dir, nom_fichier)
        with open(chemin, "rb") as f:
            st.download_button(
                label=f"📥 Télécharger ma copie ({nom_fichier})",
                data=f,
                file_name=nom_fichier,
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
    else:
        st.warning("❗ Aucune copie trouvée pour cet ID.")

    # === DÉPÔT DE LA COPIE REMPLIE ===
    st.markdown("---")
    st.subheader("📤 Déposer votre fichier Excel rempli")
    fichier_upload = st.file_uploader("Déposez votre fichier (.xlsx)", type=["xlsx"])

    if fichier_upload:
        try:
            # Charger le fichier Excel
            wb = openpyxl.load_workbook(fichier_upload)
            ws = wb.active

            # Lire métadonnées (Z1 = ID, Z2 = hash)
            id_z1 = ws["Z1"].value
            hash_z2 = ws["Z2"].value

            # Calculer hash à partir du contenu (pour info côté serveur)
            contenu = id_z1.encode()
            for row in ws.iter_rows(values_only=True):
                for cell in row:
                    if cell:
                        contenu += str(cell).encode()
            recalculated_hash = hashlib.sha256(contenu).hexdigest()

            # Sauvegarder le fichier déposé
            chemin_sauvegarde = os.path.join(depot_dir, fichier_upload.name)
            with open(chemin_sauvegarde, "wb") as out_file:
                out_file.write(fichier_upload.getbuffer())

            # Enregistrer la notification pour le professeur
            with open(notif_file, "r") as f:
                notifs = json.load(f)

            if fichier_upload.name not in notifs:
                notifs.append(fichier_upload.name)
                with open(notif_file, "w") as f:
                    json.dump(notifs, f)

            # Message simple à l'étudiant, pas de détail technique
            st.success("✅ Dépôt effectué avec succès. Votre fichier a bien été reçu.")
        except Exception as e:
            st.error(f"❌ Erreur lors du traitement de votre fichier. Veuillez réessayer.")
